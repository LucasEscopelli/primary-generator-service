package com.scalability.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectForScalabilityTestWithK8sApplicationTests {

	@Test
	void contextLoads() {
	}

}
